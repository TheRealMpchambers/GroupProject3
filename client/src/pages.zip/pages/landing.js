import React, { Component } from "react";
import { Col, Row, Container } from "../components/Grid";

class Destination extends Component {
	state = {
		destination: "",
		map: ""
	};

	componentDidMount() {
		this.loadDestination();
	}

	loadDestination() => {

	}

	render() {
		return(
			<Container fluid>
				<Row>
					<Col size="md-10">
// add nav component
						<Nav>
						</Nav>
					</Col>
				</Row>
				<Row>
					<Col size="md-10">
// add jumbotron component asking where they would like to go
						<Jumbotron>
						</Jumbotron>
					</Col>
				</Row>
			</Container>
		)
	}
}